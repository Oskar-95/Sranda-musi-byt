
const int LED_COUNT = 4;
const int DATA_PIN = 21;
const int CHANNEL = 0;
